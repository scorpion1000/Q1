## 8. Triangle area
### Write a Python program that will accept the base and height of a triangle and compute the area

print('Area of a Triangle')

# Getting User Input

base = float(input('Base : '))
  
height = float(input('Height : '))

 # Now getting into Formulae
Area = (base * height) / 2

 #Output

print(f'Area {Area} with base {base} & Height {height} ')